#define SpeedMin 30.0
#define SpeedMax 150.0
#define SpeedInc 2.5
#define Kp 8.113
#define Ki 0.5
#define ThrottleSatMax 45.0
#define PedalsMin 3.0

